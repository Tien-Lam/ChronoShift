import { convert } from "../../../web/src/engine/convert";
import { formatResult } from "../../../web/src/engine/time";
import type {
  ConversionOptions,
  TimeResult,
} from "../../../web/src/engine/types";

const $ = <T extends HTMLElement>(id: string) =>
  document.getElementById(id) as T;
const message = $<HTMLTextAreaElement>("message");
const target = $<HTMLSelectElement>("target");
const source = $<HTMLSelectElement>("source");
const reference = $<HTMLInputElement>("reference");
const dateFormat = $<HTMLSelectElement>("date-format");
const timeFormat = $<HTMLSelectElement>("time-format");
const device = Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
const samples = {
  meeting: "Friday, October 9, 2026 at 9am in New York",
  range: "October 9, 2026 from 9am to 11am in New York",
  ambiguous: "October 9, 2026 at 3pm CST",
  relative: "Tomorrow at 3pm",
};
let debounce: ReturnType<typeof setTimeout>;
let composing = false;
let revision = 0;
let copyRequest = 0;
const node = (tag: string, className: string, text?: string) => {
  const el = document.createElement(tag);
  el.className = className;
  if (text !== undefined) el.textContent = text;
  return el;
};
function options(): ConversionOptions {
  return {
    sourceZone: source.value || device,
    targetZone: target.value,
    referenceDate: reference.value || undefined,
    dateOrder: dateFormat.value as "mdy" | "dmy",
    hourCycle: timeFormat.value as "auto" | "12" | "24",
    locale: navigator.language || "en-AU",
  };
}
async function copy(button: HTMLButtonElement, text: string) {
  const owner = revision;
  const request = ++copyRequest;
  $<HTMLTextAreaElement>("copy-fallback").hidden = true;
  $("copy-status").textContent = "";
  try {
    await navigator.clipboard.writeText(text);
    if (owner === revision && request === copyRequest)
      $("copy-status").textContent = "Copied.";
  } catch {
    if (owner === revision && request === copyRequest) {
      const field = $<HTMLTextAreaElement>("copy-fallback");
      field.value = text;
      field.hidden = false;
      $("copy-status").textContent =
        "Select the text below to copy it manually.";
    }
  }
}
function addResult(
  container: HTMLElement,
  result: TimeResult,
  opts: ConversionOptions,
) {
  const d = formatResult(result, opts);
  const row = node("div", "result-row");
  const output = node("div", "output");
  const clock = node("p", "result-time");
  if (d.time) {
    const numeral = d.time.match(/\p{N}+(?:[:.,٫]\p{N}+)+/u);
    if (numeral) {
      const at = numeral.index!;
      clock.append(document.createTextNode(d.time.slice(0, at)));
      clock.append(node("span", "time-number", numeral[0]));
      clock.append(
        document.createTextNode(d.time.slice(at + numeral[0].length)),
      );
      if (Array.from(numeral[0]).length > 8) clock.classList.add("precision");
    } else clock.textContent = d.time;
  } else clock.textContent = d.date;
  output.append(clock);
  if (d.time) output.append(node("p", "result-date", d.date));
  output.append(
    node(
      "p",
      "result-zone",
      d.zone +
        (d.dateShift
          ? ` · ${d.dateShift > 0 ? "+" : ""}${d.dateShift} ${Math.abs(d.dateShift) === 1 ? "day" : "days"}`
          : ""),
    ),
  );
  row.append(output);
  const button = node("button", "copy", "Copy") as HTMLButtonElement;
  button.type = "button";
  button.setAttribute(
    "aria-label",
    `Copy ${d.time || d.date}, ${d.date}, ${d.zone}`,
  );
  const sourceLabel = result.sourceLabel.startsWith("Unix seconds")
    ? "UTC"
    : result.sourceLabel;
  const copied = `${d.time ? d.time + " · " : ""}${d.date} · ${d.zone}\n${result.original} — ${sourceLabel}${result.interpretation ? " · " + result.interpretation : ""}${result.assumptions.length ? "\n" + result.assumptions.join("; ") : ""}`;
  button.addEventListener("click", () => copy(button, copied));
  row.append(button);
  container.append(row);
  container.append(
    node("p", "source-context", result.interpretation || `From ${sourceLabel}`),
  );
  if (result.dateOnly)
    container.append(
      node(
        "p",
        "assumption",
        "A date without a time cannot be shifted between time zones.",
      ),
    );
  result.assumptions.forEach((a) =>
    container.append(
      node("p", "assumption", a.replace("timezone", "time zone")),
    ),
  );
}
function render() {
  clearTimeout(debounce);
  revision++;
  const chosenSource = source.value
    ? source.selectedOptions[0].textContent
    : device.replaceAll("_", " ");
  $("source-default").textContent =
    `If the message has no time zone, use ${chosenSource}. An explicit zone in the message takes priority.`;
  const results = $("results");
  results.replaceChildren();
  $("copy-status").textContent = "";
  $<HTMLTextAreaElement>("copy-fallback").hidden = true;
  $("destination").textContent = target.selectedOptions[0].textContent;
  if (!message.value.trim()) {
    results.append(node("div", "empty", "Your local times will appear here."));
    $("result-count").textContent = "Ready when you are";
    return;
  }
  if (!reference.checkValidity()) {
    const error = node("p", "warning", "Choose a valid reference date.");
    error.setAttribute("role", "alert");
    results.append(error);
    $("result-count").textContent = "Check the reference date";
    return;
  }
  try {
    const opts = options();
    const conversion = convert(message.value, opts);
    conversion.warnings.forEach((w) => {
      const warning = node("p", "warning", w);
      warning.setAttribute("role", "alert");
      results.append(warning);
    });
    const groups = new Map<string, TimeResult[]>();
    conversion.results.forEach((r) => {
      const key = `${r.sourceIndex}:${r.original}`;
      groups.set(key, [...(groups.get(key) || []), r]);
    });
    let alternatives = false;
    for (const entries of groups.values()) {
      const article = node("article", "result-card");
      const branches = new Map<string, TimeResult[]>();
      entries.forEach((r) =>
        branches.set(r.endpoint || "time", [
          ...(branches.get(r.endpoint || "time") || []),
          r,
        ]),
      );
      const count = Math.max(
        ...Array.from(branches.values()).map((x) => x.length),
      );
      if (count > 1) {
        alternatives = true;
        article.append(
          node(
            "p",
            "ambiguity",
            `${count} possible interpretations · choose the intended time zone`,
          ),
        );
      }
      entries.forEach((r) => addResult(article, r, opts));
      article.append(
        node("p", "original", `Original: “${entries[0].original}”`),
      );
      results.append(article);
    }
    if (!conversion.results.length && !conversion.warnings.length)
      results.append(
        node(
          "div",
          "empty",
          "No clear time found. Try adding a date, time or city.",
        ),
      );
    $("result-count").textContent = alternatives
      ? "Check the alternatives below"
      : `${conversion.results.length} ${conversion.results.length === 1 ? "time" : "times"} converted`;
  } catch (error) {
    const warning = node(
      "p",
      "warning",
      error instanceof Error
        ? error.message
        : "Check the message and try again.",
    );
    warning.setAttribute("role", "alert");
    results.append(warning);
    $("result-count").textContent = "Check your message";
  }
}
function schedule() {
  clearTimeout(debounce);
  revision++;
  document
    .querySelectorAll<HTMLButtonElement>(".copy")
    .forEach((button) => (button.disabled = true));
  $<HTMLTextAreaElement>("copy-fallback").hidden = true;
  $("copy-status").textContent = "";
  if (composing) {
    $("result-count").textContent = "Finish typing to convert";
    return;
  }
  $("result-count").textContent = "Updating…";
  debounce = setTimeout(render, 180);
}
message.addEventListener("input", schedule);
message.addEventListener("compositionstart", () => {
  composing = true;
  schedule();
});
message.addEventListener("compositionend", () => {
  composing = false;
  schedule();
});
[target, source, reference, dateFormat, timeFormat].forEach((el) =>
  el.addEventListener("change", render),
);
$("clear").addEventListener("click", () => {
  message.value = "";
  render();
  message.focus();
});
$<HTMLSelectElement>("example").addEventListener("change", (e) => {
  const kind = (e.target as HTMLSelectElement).value as keyof typeof samples;
  if (kind) {
    message.value = samples[kind];
    render();
  }
});
$("theme").addEventListener("click", () => {
  const dark = document.body.dataset.theme === "dark";
  document.body.dataset.theme = dark ? "light" : "dark";
  $("theme").textContent = dark ? "Dark mode" : "Light mode";
});
$("reset").addEventListener("click", () => {
  source.value = "";
  reference.value = "";
  dateFormat.value = "mdy";
  timeFormat.value = "auto";
  render();
});
message.value = samples.meeting;
render();
