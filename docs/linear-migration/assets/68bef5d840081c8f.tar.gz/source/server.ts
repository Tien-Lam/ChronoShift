const root = import.meta.dir + "/../dist";
const routes = new Set([
  "index.html",
  "a.html",
  "b.html",
  "c.html",
  "app.css",
  "app.js",
  "geist.woff2",
  "a.jpg",
  "b.jpg",
  "c.jpg",
]);
const server = Bun.serve({
  hostname: "127.0.0.1",
  port: 43873,
  fetch(request) {
    const path = new URL(request.url).pathname.slice(1) || "index.html";
    if (!routes.has(path)) return new Response("Not found", { status: 404 });
    return new Response(Bun.file(root + "/" + path), {
      headers: {
        "Cache-Control": "no-store",
        "Content-Security-Policy":
          "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'none'; img-src 'self'; font-src 'self'; frame-src 'self'; base-uri 'none'; form-action 'none'",
      },
    });
  },
});
console.log(`Local: http://127.0.0.1:${server.port}`);
